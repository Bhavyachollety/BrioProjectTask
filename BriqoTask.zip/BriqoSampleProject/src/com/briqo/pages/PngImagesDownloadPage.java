package com.briqo.pages;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class PngImagesDownloadPage {

	WebDriver driver;

	public PngImagesDownloadPage(WebDriver driver)

	{

		this.driver=driver;
	}

	public void ImagesDownload() throws Exception {



		
		//WebElement logo =   driver.findElement(By.xpath("//*[@id=\"content\"]/div/a[2]"));

		 //String logoSRC = logo.getAttribute("src");

		 //URL imageURL = new URL(logoSRC);

		 //BufferedImage saveImage = ImageIO.read(imageURL);

		// ImageIO.write(saveImage, "png", new File("logo-image.png"));
		
		
	
		
			   WebElement Image =driver.findElement(By.xpath("//*[@id=\"content\"]/div/a[2]"));
	//		  Right click on Image using contextClick() method.
			  Actions action= new Actions(driver);
			  action.contextClick(Image).build().perform();
		
			// To perform press Ctrl + v keyboard button action.
			  action.sendKeys(Keys.CONTROL, "v").build().perform();
		
		     driver.close();
		
		
		}
	}
