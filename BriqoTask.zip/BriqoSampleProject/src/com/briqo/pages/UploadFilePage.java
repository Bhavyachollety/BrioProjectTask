package com.briqo.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class UploadFilePage {

	WebDriver driver;
	
	
	WebElement upload = driver.findElement(By.xpath("//*[@id=\"file-upload\"]"));

	public UploadFilePage(WebDriver driver)

	{

		this.driver=driver;
	}
	
	
	public void uploadFile() {
		
		upload.click();
		upload.sendKeys("C://Users//Vilaskar//Desktop//New Microsoft Excel Worksheet.xlsx");
		
		System.out.println("File is Uploaded Successfully");
		 
	}
}
