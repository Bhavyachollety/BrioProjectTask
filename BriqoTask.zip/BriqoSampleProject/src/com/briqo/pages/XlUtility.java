package com.briqo.pages;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;



public class XlUtility {


	public FileInputStream fi;
	public OutputStream fo;
	public XSSFWorkbook workbook;
	public XSSFSheet sheet;
	public XSSFRow row;
	public XSSFCell cell;
	public CellStyle style;
	
	String path;
	
	public XlUtility(String path){
	
		this.path = path;
		
	}
	
    public int getRowCount(String sheetName) throws Exception	 {
    	
    	fi = new FileInputStream(path);
    	workbook = new XSSFWorkbook(fi);
    	
    	sheet = workbook.getSheet(sheetName);
    	int rowCount = sheet.getLastRowNum();
    	workbook.close();
    	fi.close();
    	
    	
		return rowCount;
    
    	
    }
    
    public int getCellCount(String sheetName,int rownum) throws Exception {
    	
    	fi = new FileInputStream(path);
    	workbook = new XSSFWorkbook(fi);
    	
    	sheet = workbook.getSheet(sheetName);
    	row = sheet.getRow(rownum);
    	int cellCount = sheet.getLastRowNum();
    	workbook.close();
    	fi.close();
    	
    	
		return cellCount;
    	
    }
    
    
    public String getCellData(String sheetName,int rownum, int colnum) throws Exception {
		
    	fi = new FileInputStream(path);
    	workbook = new XSSFWorkbook(fi);
    	
    	sheet = workbook.getSheet(sheetName);
    	row = sheet.getRow(rownum);
    	cell = row.getCell(colnum);
    	
    	DataFormatter formatter = new DataFormatter();
    	
    	String data;
    	
    	try {
    		
    		data = formatter.formatCellValue(cell);
    	}
    	
    	catch(Exception e) {
    		
    		data = " ";
    		
    	}
    	
    	workbook.close();
    	fi.close();
    	return data;
    	
    }
    
    public void setCellData(String sheetName,int rownum, int colnum, String Data) throws Exception {
    	
    	File xlfile = new File(path);
    	
    	if(!xlfile.exists()) {
    		
    	    workbook = new XSSFWorkbook(path);
    	    
    	    fo = new FileOutputStream(path);
    	    
    	    workbook.write(fo);
    	}
    	
    	fi = new FileInputStream(path);
    	 workbook = new XSSFWorkbook(fi);
    	 	
    
    
    if(workbook.getSheetIndex(sheetName)==-1) {
    	
    	workbook.createSheet(sheetName);
    	
    	sheet = workbook.getSheet(sheetName);
    	
    	if(sheet.getRow(rownum)==null)
    		
    		sheet.createRow(rownum);
    		
    	row = sheet.getRow(rownum);
    	
    	cell = row.createCell(colnum);
    	
    	cell.setCellValue(Data);
    	
    	fo = new FileOutputStream(path);
    	workbook.write(fo);
    	workbook.close();
    	fi.close();
    	fo.close();
    	
    
    }
    
}
}
