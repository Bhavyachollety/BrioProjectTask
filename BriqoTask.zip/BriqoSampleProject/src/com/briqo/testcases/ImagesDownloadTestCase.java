package com.briqo.testcases;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import com.briqo.pages.PngImagesDownloadPage;

public class ImagesDownloadTestCase {

	@Test(priority=1)
	public void ImageDowloadTestCase() throws Exception {

		System.setProperty("webdriver.chrome.driver","C://Users//Vilaskar//Downloads//chromedriver-win32 (1)//chromedriver-win32//chromedriver.exe");
		WebDriver driver = new ChromeDriver();



		driver.manage().window().maximize();


		driver.manage().timeouts().implicitlyWait(2000, TimeUnit.MILLISECONDS);

		driver.get("https://the-internet.herokuapp.com/download");

       
		PngImagesDownloadPage obj = new PngImagesDownloadPage(driver);
		
			obj.ImagesDownload();
			
			

	}
}
