package com.briqo.testcases;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import com.briqo.pages.XlUtility;

public class TableDataReadTestCase {


	@Test(priority=1)

	public void TableDataDisplay() throws Exception {

	System.setProperty("webdriver.chrome.driver","C://Users//Vilaskar//Downloads//chromedriver-win32 (1)//chromedriver-win32//chromedriver.exe");
	WebDriver driver = new ChromeDriver();


	driver.manage().window().maximize();


	driver.manage().timeouts().implicitlyWait(2000, TimeUnit.MILLISECONDS);

	driver.get("http://the-internet.herokuapp.com/challenging_dom");

	String path = ".\\TestDataFolder\\TableData.xlsx";
	
	XlUtility xlutil = new XlUtility(path);
	
     // write headers in util
	
	xlutil.setCellData("Sheet1", 0, 0, "Lorem");
	xlutil.setCellData("Sheet1", 0, 1, "Ipsum");
	xlutil.setCellData("Sheet1", 0, 2, "Dolor");
	xlutil.setCellData("Sheet1", 0, 3, "Sit");
	xlutil.setCellData("Sheet1", 0, 4, "Amet");
	xlutil.setCellData("Sheet1", 0, 5, "Diceret");
		
	
	//capturing table details
	
	WebElement table = driver.findElement(By.xpath("//*[@id=\"content\"]/div/div/div/div[2]/table/tbody"));
	
	int rows = table.findElements(By.xpath("tr")).size();
	
	for(int r=1;r<=rows;r++) {
		
		
		String firstvalue = table.findElement(By.xpath("tr["+r+"]/td[1]")).getText();
		String secondvalue = table.findElement(By.xpath("tr["+r+"]/td[2]")).getText();
		String thirdvalue = table.findElement(By.xpath("tr["+r+"]/td[3]")).getText();
		String fourthvalue = table.findElement(By.xpath("tr["+r+"]/td[4]")).getText();
		String fivthvalue = table.findElement(By.xpath("tr["+r+"]/td[5]")).getText();
		String sixvalue = table.findElement(By.xpath("tr["+r+"]/td[6]")).getText();
		
		System.out.println(firstvalue+secondvalue+thirdvalue+fourthvalue+fivthvalue+sixvalue);
		
		// writing data in to excel
		
		xlutil.setCellData("Sheet1",r, 0,firstvalue);
		xlutil.setCellData("Sheet1",r, 1,secondvalue);
		xlutil.setCellData("Sheet1",r, 2,thirdvalue);
		xlutil.setCellData("Sheet1",r, 3,fourthvalue);
		xlutil.setCellData("Sheet1",r, 4,fivthvalue);
		xlutil.setCellData("Sheet1",r, 5,sixvalue);
		
	}
	
	
	System.out.println("Web wraaping down successfully");
	
	driver.close();
	
	
	
	
	
	
	
	
}
}