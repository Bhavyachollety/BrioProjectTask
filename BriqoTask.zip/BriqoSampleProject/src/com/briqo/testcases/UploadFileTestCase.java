package com.briqo.testcases;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import com.briqo.pages.PngImagesDownloadPage;
import com.briqo.pages.UploadFilePage;

public class UploadFileTestCase {

	@Test(priority=1)
	public void LaunchBrowser() {
		
System.setProperty("webdriver.chrome.driver","C://Users//Vilaskar//Downloads//chromedriver-win32 (1)//chromedriver-win32//chromedriver.exe");
	WebDriver driver = new ChromeDriver();

	driver.manage().window().maximize();


	driver.manage().timeouts().implicitlyWait(2000, TimeUnit.MILLISECONDS);

	driver.get("https://the-internet.herokuapp.com/upload");

   
	UploadFilePage obj = new UploadFilePage(driver);
	
	obj.uploadFile();
}
}
